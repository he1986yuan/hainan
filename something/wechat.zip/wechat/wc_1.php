<?php
require './wechat.class.php';
define('APPID','wxd1fb3b4932bcaff2');
define('APPSECRET','c7743bc0f2f9ee52c3c7d44628eb6845');
define('TOKEN','heyuan')
$wechat =new WeChat(APPID,APPSECRET,TOKEN);
// $token =$wechat->getAccessToken();
// var_dump($token);
//var_dump($wechat->getQRCode(1234,'./1234.jpeg'));
$wechat->firstValid();

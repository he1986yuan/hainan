<?php
/**
 * wechat  controller class
 */
class Wechat //extends AnotherClass
{

  private $_appid;
  private $_appsecret;
  private $_token;//公众平台请求开发者时候的参数
  //Qrcode的类型
  const QRCODE_TYPE_TEMP=1;
  const QRCODE_TYPE_LIMIT =2;
  const QRCODE_TYPE_LIMIT_STR =3;
  public function __construct($id,$secret,$token)
  {
    //get appid and appsecret
    $this->_appid =$id;
    $this->_appsecret=$secret;
    $this->_token =$token;
  }
  /**
   * 在wechat请求PHP时验证signature的合法性
   */
  public function firstValid()
  {
    //如果签名合法返回随机字符串
    if ($this->_checkSignature()) {
      echo $_GET['echostr'];
    }
  }
  /**
   * @return bool [description]
   */
   private function _checkSignature()
   {
     $signature =$_GET['signature'];//微信传来的签名（来自我们在品台上事先填好的token运算而成）
     $timestamp =$_GET['timestamp'];//传来的时间戳
     $nonce =$_GET['nonce'];
     $tmp_arr =array($this->_token,$timestamp,$nonce);
     sort($tmp_arr,SORT_STRING);//字典的顺序
     $tmp_str =implode($tmp_arr);//把数组项链接成字符串
     $tmp_str =sha1($tmp_str);//sha1签名算法
     if ($signature ==$tmp_str) {//如果本地保留的token计算而来的签名等于传递而来的签名
       return true;
     }else{
       return false;
     }
   }


  //获取微信的acessToken
  public function getAccessToken($token_file ='./access_token')
  {
    $life_time=7200;
    //如果时间没有过期则直接返回文件中的access_token否则重新获取access_token
    // if (file_exists($token_file) && time()-filetime($token_file)<$life_time) {
    //    return file_get_contents($token_file);
    // }

    $url ="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$this->_appid}&secret={$this->_appsecret}";
    //send request GET
    //var_dump($url);
    $result =$this->_requestGet($url,$ssl=true);
    if (!$result) {
      return false;
    }
    $obj =json_decode($result);//如果填写第二个参数就是数组，否则返回的就是对象//{"access_token":"ACCESS_TOKEN","expires_in":7200}
    //写入文件
    //file_put_contents($token_file,$obj->access_token);
    return $obj->access_token;


  }
  public  function _getQRCodeTicket($content,$type=2)//这里写死了我们用固定的action类型2：-。-
  {
    $access_token =$this->getAccessToken();
    $url ="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=$access_token";
    //echo "$url</br>";
    //qrcode 的类型
    $type_list =[
      self::QRCODE_TYPE_TEMP=>'QR_SCENE',
      self::QRCODE_TYPE_LIMIT=>'QR_LIMIT_SCENE',
      self::QRCODE_TYPE_LIMIT_STR=>'QR_LIMIT_STR_SCENE',
    ];
    $action_name =$type_list[$type];
    $data ='{"action_name": "'.$action_name.'", "action_info": {"scene": {"scene_id": "'.$content.'"}}}';
    //echo "$data</br>";
    // die;
    $result =$this->_requestPost($url,$data);
    if (!$result) {
      return false;
    }
    $result_obj =json_decode($result);
    // var_dump($access_token);
    // var_dump($result_obj);
    return $ticket =$result_obj->ticket;
  }
  /**
   * request POST
   *@param [type] string [$url]
   *@param [type] string [$data]
   *@param [type] bool [$ssl]
   *@return[type] string
   */

  public function _requestPost($url,$data,$ssl=true)
  {

      $curl =curl_init();
      //设置CURL选项
      curl_setopt($curl,CURLOPT_URL,$url);
      $user_agent =isset($_SERVER['HTTP_SERVER_USER_AGENT']) ? $_SERVER['HTTP_SERVER_USER_AGENT']:"User-Agent:Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.22 Safari/537.36 SE 2.X MetaSr 1.0";
      curl_setopt($curl,CURLOPT_USERAGENT,$user_agent);
      //请求来源
      curl_setopt($curl,CURLOPT_AUTOREFERER,true);
      //不验证ssl证书
      if ($ssl) {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); //https请求 不验证证书 其实只用这个就可以了
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); //https请求 不验证HOST
      }
      //处理响应
      curl_setopt($curl,CURLOPT_POST,true); //请求的url
      curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
      curl_setopt($curl,CURLOPT_HEADER,false);//不处理请求头
      curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);//返回响应结果
      //send request
      $response =curl_exec($curl);
      if (false==$response) {
        echo curl_error($curl);
        return false;
      }
      return $response;

  }
  //获取二维码
  public function getQRCode($content,$file=null)
  {
    $ticket =$this->_getQRCodeTicket($content);
    //var_dump($ticket);
    $url ="https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=$ticket";
    $result =$this->_requestGet($url);//获取的是图像资源
    if ($file) {
      file_put_contents($file,$result);
    }else{
      header('Content-type:image/jpeg');
      echo $result;
    }
  }

  /**
   * request GET
   *@param [type] string [$url]
   *@param [type] bool [$ssl]
   *@return[type] stringl
   */
  public function _requestGet($url,$ssl=true)
  {
    $curl =curl_init();
    //设置CURL选项
    curl_setopt($curl,CURLOPT_URL,$url);
    $user_agent =isset($_SERVER['HTTP_SERVER_USER_AGENT']) ? $_SERVER['HTTP_SERVER_USER_AGENT']:"User-Agent:Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.22 Safari/537.36 SE 2.X MetaSr 1.0";
    curl_setopt($curl,CURLOPT_USERAGENT,$user_agent);
    //请求来源
    curl_setopt($curl,CURLOPT_AUTOREFERER,true);
    //不验证ssl证书
    if ($ssl) {
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); //https请求 不验证证书 其实只用这个就可以了
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); //https请求 不验证HOST
    }
    //处理响应
    curl_setopt($curl,CURLOPT_URL,$url); //请求的UR
    curl_setopt($curl,CURLOPT_HEADER,false);//不处理请求头
    curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);//返回响应结果
    //send requere
    $response =curl_exec($curl);
    if (false==$response) {
      echo curl_error($curl);
      return false;
    }
    return $response;

  }
}



 ?>
